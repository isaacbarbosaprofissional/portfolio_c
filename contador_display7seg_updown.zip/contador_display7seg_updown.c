﻿/*******************************************************************************
*      O propósito do algoritmo é a implementação de um sistema de contagem    *
* utilizando um display de 7 segmentos.                                        *
*                                                                              *
*      O programa controla a exibição dos números de 0 a 9 no display.         *
* Dependendo do estado do botão (BT0), o contador funciona de duas formas:     *
*                                                                              *
*   - Quando o botão está desligado (OFF), o display realiza contagem          *
*     crescente, indo de 0 até 9.                                              *
*                                                                              *
*   - Quando o botão está ligado (ON), o display realiza contagem              *
*     decrescente, indo de 9 até 0.                                            *
*                                                                              *
*      Cada número é exibido por 1 segundo antes de avançar para o próximo.    *
* O hardware é configurado por meio dos PORTs, que acionam os segmentos        *
* (a, b, c, d, e, f, g e ponto decimal) de acordo com a tabela de sinais.      *
*******************************************************************************/

#define Data_a  PORTC.B3   // Segmento A do display
#define Data_b  PORTC.B2   // Segmento B do display
#define Data_c  PORTC.B1   // Segmento C do display
#define Data_d  PORTC.B0   // Segmento D do display
#define Data_e  PORTB.B3   // Segmento E do display
#define Data_f  PORTB.B2   // Segmento F do display
#define Data_g  PORTB.B1   // Segmento G do display
#define Data_ponto_decimal PORTB.B0   // Segmento do ponto decimal
#define BT0 PIND.B2        // Botão de controle (crescente/decrescente)
#define ON 1               // Estado lógico ligado
#define OFF 0              // Estado lógico desligado

unsigned char DisplayCode;  // Variável que guarda o valor do dígito codificado
signed char cnt = 0;        // Contador (de 0 a 9)

// Função de configuração dos pinos como entrada ou saída
void Configura (void)
{
 DDRC.B3 = 1;  // Saída
 DDRC.B2 = 1;
 DDRC.B1 = 1;
 DDRC.B0 = 1;
 DDRB.B3 = 1;
 DDRB.B2 = 1;
 DDRB.B1 = 1;
 DDRB.B0 = 1;
 DDRD.B2 = 0;  // Entrada (botão)
}

// Tabela com os códigos binários que acendem os segmentos do display de 0 a 9
unsigned char Tab_Sinal[ ] = {
 0b11111100, // Dígito 0
 0b01100000, // Dígito 1
 0b11011010, // Dígito 2
 0b11110010, // Dígito 3
 0b01100110, // Dígito 4
 0b10110110, // Dígito 5
 0b10111110, // Dígito 6
 0b11100000, // Dígito 7
 0b11111110, // Dígito 8
 0b11110110  // Dígito 9
};

// Função de segurança: desliga todos os segmentos
void Desligar(void)
{
 Data_a = 0;
 Data_b = 0;
 Data_c = 0;
 Data_d = 0;
 Data_e = 0;
 Data_f = 0;
 Data_g = 0;
 Data_ponto_decimal = 0;
}

void main (void)
{
 Configura(); // Inicializa hardware
 Desligar(); // Segurança: apaga display quando não está contando

 while (1) // Loop infinito
 {
   // --- Contagem crescente (0 → 9) enquanto botão não for pressionado ---
   while (BT0 == OFF)
   {
     DisplayCode = Tab_Sinal[cnt]; // Pega código do dígito
     cnt = cnt + 1;                // Incrementa contador

     // Envia os bits para os segmentos
     Data_a = DisplayCode.B7;
     Data_b = DisplayCode.B6;
     Data_c = DisplayCode.B5;
     Data_d = DisplayCode.B4;
     Data_e = DisplayCode.B3;
     Data_f = DisplayCode.B2;
     Data_g = DisplayCode.B1;
     Data_ponto_decimal = DisplayCode.B0;

     if (cnt > 9) cnt = 0; // Reinicia no 0
     delay_ms(1000);
   }

   // --- Contagem decrescente (9 → 0) enquanto botão for pressionado ---
   while (BT0 == ON)
   {
     DisplayCode = Tab_Sinal[cnt]; // Pega código do dígito
     cnt = cnt - 1;                // Decrementa contador

     // Envia os bits para os segmentos
     Data_a = DisplayCode.B7;
     Data_b = DisplayCode.B6;
     Data_c = DisplayCode.B5;
     Data_d = DisplayCode.B4;
     Data_e = DisplayCode.B3;
     Data_f = DisplayCode.B2;
     Data_g = DisplayCode.B1;
     Data_ponto_decimal = DisplayCode.B0;

     if (cnt < 0) cnt = 9; // Reinicia no 9
     delay_ms(1000);
   }
 }
}
