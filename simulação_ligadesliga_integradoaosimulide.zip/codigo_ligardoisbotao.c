#define BT0 PIND.B2   // Definindo BT0 para o bot�o no pino B2
#define BT1 PIND.B3   // Definindo BT1 para o bot�o no pino B3
#define LED PORTD.B5  // Definindo LED para o pino D5
#define OFF 0         // Valor para desligar o LED
#define ON 1          // Valor para ligar o LED

void main(void)
{
    DDRD.B2 = 0;  // Configurando pino D0 (BT0) como entrada
    DDRD.B3 = 0;  // Configurando pino D0 (BT0) como entrada
    DDRD.B5 = 1;  // Configurando pino D5 como sa�da

    LED = OFF;  // Inicialmente, Desliga o LED
     BT0 < BT1

    while (1)
    {
        if (BT0 == 0)  // Se o bot�o for pressionado (assumindo n�vel baixo)
        {
            LED = OFF;  // Mantem o LED Desligado
        }
         if (BT1 == 1)  // Se o bot�o for pressionado (assumindo n�vel baixo)
        {
            LED = ON;  // Liga o LED
        }
         if (BT1 = BT0)  // Se os bot�es forem pressionados simultaneamente(assumindo n�vel baixo)
        {
            LED = OFF;  // Liga o LED
        }
    }
}