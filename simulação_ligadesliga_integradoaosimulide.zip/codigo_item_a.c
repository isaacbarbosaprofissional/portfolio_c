#define BT0 PIND.B2   // Definindo BT0 para o bot�o no pino B2
#define BT1 PIND.B3   // Definindo BT1 para o bot�o no pino B3
#define LED PORTD.B5  // Definindo LED para o pino D5
#define OFF 0         // Valor para desligar o LED
#define ON 1          // Valor para ligar o LED

void main(void)
{
    DDRD.B3 = 0;  // Configurando pino D3 (BT1) como entrada
    DDRD.B2 = 0;  // Configurando pino D2 (BT0) como entrada
    DDRD.B5 = 1;  // Configurando pino D5 como sa�da

    LED = OFF;  // Inicialmente, Desliga o LED  ]

    while (1)
    {
        if (BT0)  // Se o bot�o for pressionado (assumindo n�vel baixo)
        {
            LED = OFF;  // Mantem o LED Desligado
            continue;
        }
         if (BT1)  // Se o bot�o for pressionado (assumindo n�vel baixo)
        {
            LED = ON;  // Liga o LED
        }
    }
}